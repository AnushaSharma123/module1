package com.in.oirs.bean;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class oirsBean
 */
@WebServlet("/oirsBean")
public class oirsBean extends HttpServlet {
	private String UserId;
	private String userPassword;
	private String Role;
	
    public String getRole() {
		return Role;
	}


	public void setRole(String role) {
		Role = role;
	}


	public String getUserId() {
		return UserId;
	}


	public void setUserId(String userId) {
		UserId = userId;
	}


	public String getUserPassword() {
		return userPassword;
	}


	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}


	public oirsBean() {
        super();
        // TODO Auto-generated constructor stub
    }

	

}
