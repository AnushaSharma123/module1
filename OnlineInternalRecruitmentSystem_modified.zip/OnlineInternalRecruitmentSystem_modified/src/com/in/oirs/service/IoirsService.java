package com.in.oirs.service;

import com.in.oirs.bean.oirsBean;

public interface IoirsService {
	public abstract String isValidUser(oirsBean bean);
}
