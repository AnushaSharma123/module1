package com.in.oirs.service;

import com.in.oirs.bean.oirsBean;
import com.in.oirs.dao.IoirsDAO;
import com.in.oirs.dao.OirsDAO;

public class OirsService implements IoirsService{

	@Override
	public String isValidUser(oirsBean bean) {
		IoirsDAO dao = new OirsDAO();
		return dao.isValidUser(bean);
	}

}
