package com.in.oirs.dao;

import com.in.oirs.bean.oirsBean;

public interface IoirsDAO {
	public abstract String isValidUser(oirsBean bean);
}
