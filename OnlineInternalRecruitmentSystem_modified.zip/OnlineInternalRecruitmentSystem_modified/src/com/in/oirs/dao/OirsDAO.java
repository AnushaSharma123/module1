package com.in.oirs.dao;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.in.oirs.bean.oirsBean;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class OirsDAO implements IoirsDAO{
	Connection connection = null;
	boolean ans;
	@Override
	public String isValidUser(oirsBean bean) {
		try {
			InitialContext ic = new InitialContext();
			DataSource ds = (DataSource) ic.lookup("java:/OracleDS");
			String Id = bean.getUserId();
			String pswd = bean.getUserPassword();
			String role = bean.getRole();
			connection = ds.getConnection();
			Statement st = connection.createStatement();
			ResultSet rs = st.executeQuery("select count(*) from tbl_user_master where USER_ID='"+Id+"' AND PASSWORD='"+pswd+"' AND ROLE='"+role+"'");
			rs.next();
			if(rs.getInt(1) > 0)
				ans = true;
			else 
				ans = false;
			
			connection.close();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bean.getRole(); 
	}

}
