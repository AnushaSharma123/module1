package com.in.oirs.pi;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.in.oirs.bean.oirsBean;
import com.in.oirs.service.IoirsService;
import com.in.oirs.service.OirsService;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class Controller extends HttpServlet {

	oirsBean bean = new oirsBean(); 
	IoirsService service = new OirsService();
    public Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String UserId = request.getParameter("Id");
		String Password = request.getParameter("password");
		String role = request.getParameter("role");
		bean.setUserId(UserId);
		bean.setUserPassword(Password);
		bean.setRole(role);
		String role1 = service.isValidUser(bean);
		if(role1 == "admin")
		{
			getServletContext().getRequestDispatcher("/AdminPage.jsp").forward(request,response);
		}
		else if(role1 == "rm")
		{
			getServletContext().getRequestDispatcher("/RmPage.jsp").forward(request,response);
		}
		else if(role1 == "rmge")
		{
			getServletContext().getRequestDispatcher("/RmgePage.jsp").forward(request,response);
		}
		else
		{
			System.out.println("Invalid role");
		}
	}

}
