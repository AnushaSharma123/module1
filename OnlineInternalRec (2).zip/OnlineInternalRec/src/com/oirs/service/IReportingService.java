package com.oirs.service;

public interface IReportingService {

}
