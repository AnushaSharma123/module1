SQL> CREATE TABLE salgrade(grade CHAR(2) PRIMARY KEY,
  2      minsal NUMBER,
  3      maxsal NUMBER);

Table created.

SQL>  CREATE TABLE employees(employee_code NUMBER PRIMARY KEY,
  2     employee_name VARCHAR2(15),
  3     date_of_joining DATE,
  4     employee_salary NUMBER,
  5     grade CHAR(2) references salgrade(grade));

Table created.


SQL>  INSERT INTO salgrade VALUES('A',10000,20000);

1 row created.

SQL>  INSERT INTO salgrade VALUES('B',20001,40000);

1 row created.

SQL>  INSERT INTO salgrade VALUES('C',40001,60000);

1 row created.

SQL> select * from salgrade;

GR     MINSAL     MAXSAL
-- ---------- ----------
A       10000      20000
B       20001      40000
C       40001      60000




SQL>  INSERT INTO employees VALUES(101,'Preetam','10-JAN-2010',18000,'A');

1 row created.

SQL>  INSERT INTO employees VALUES(102,'Aakash','10-NOV-2005',48000,'C');

1 row created.

SQL>  INSERT INTO employees VALUES(103,'Kishore','19-DEC-2011',21000,'B');

1 row created.

SQL>  INSERT INTO employees VALUES(104,'Reena','23-JUN-2006',42000,'C');

1 row created.

SQL>  INSERT INTO employees VALUES(105,'Kailash','05-FEB-2004',46000,'C');

1 row created.

SQL> INSERT INTO employees VALUES(107,'Keerthana','25-JUL-2006',27000,'B');

1 row created.

SQL>  INSERT INTO employees VALUES(106,'Sahana','18-NOV-2003',52000,'C');

1 row created.

SQL> SELECT * FROM EMPLOYEES;

EMPLOYEE_CODE EMPLOYEE_NAME   DATE_OF_J EMPLOYEE_SALARY GR
------------- --------------- --------- --------------- --
          101 Preetam         10-JAN-10           18000 A
          102 Aakash          10-NOV-05           48000 C
          103 Kishore         19-DEC-11           21000 B
          104 Reena           23-JUN-06           42000 C
          105 Kailash         05-FEB-04           46000 C
          107 Keerthana       25-JUL-06           27000 B
          106 Sahana          18-NOV-03           52000 C

7 rows selected.



SQL> CREATE SEQUENCE empCode_Seq
  2                        START WITH 108;

Sequence created.


  
  
  


1)
CREATE OR REPLACE PROCEDURE EmpDetails(emp_code IN NUMBER) AS
	v_count NUMBER;
	v_empname VARCHAR2(15);
	v_empsal NUMBER;
	v_empgrade CHAR(5);
	v_minsal NUMBER;
	v_maxsal NUMBER;
	EmpNotFound EXCEPTION;
  BEGIN
    SELECT COUNT(emp.employee_code) INTO v_count FROM employees emp WHERE emp.employee_code=emp_code;
		IF v_count <1 THEN
            RAISE EmpNotFound;
		END IF;
	SELECT e.employee_name,e.employee_salary,e.grade,s.minsal,s.maxsal INTO v_empname,v_empsal,v_empgrade,v_minsal,v_maxsal
	FROM employees e,salgrade s WHERE e.grade=s.grade and e.employee_code=emp_code;
	DBMS_OUTPUT.PUT_LINE(v_empname ||' '||v_empsal||' '||v_empgrade||' '||v_minsal||' '||v_maxsal);
	EXCEPTION
		WHEN EmpNotFound THEN
             DBMS_OUTPUT.PUT_LINE('EMPLOYEE DOES NOT EXIST');
		 
END EmpDetails;

Procedure created.

SQL> execute EmpDetails(106);
Sahana 52000 C     40001 60000

PL/SQL procedure successfully completed.



2)
b)
SQL>   ALTER TABLE employees ADD (title VARCHAR2(5));

Table altered.

SQL> desc employees;
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------

 EMPLOYEE_CODE                             NOT NULL NUMBER
 EMPLOYEE_NAME                                      VARCHAR2(15)
 DATE_OF_JOINING                                    DATE
 EMPLOYEE_SALARY                                    NUMBER
 GRADE                                              CHAR(2)
 TITLE                                              VARCHAR2(5)
 
 

2)
c)
SQL> SELECT count(employee_code)
  2  FROM employees
  3  WHERE employee_salary > (SELECT avg(employee_salary)
  4  FROM employees)
  5  /

COUNT(EMPLOYEE_CODE)
--------------------
                   4




				   
3)
SQL> CREATE SEQUENCE empcode_Seq START WITH 108;

Sequence created.

SQL> INSERT INTO employees VALUES(empcode_Seq.NEXTVAL,'suma',SYSDATE,40000,'A','Mrs');

1 row created.

SQL> INSERT INTO employees VALUES(empcode_Seq.NEXTVAL,'Sumanth',SYSDATE,30000,'C','Mr');

1 row created. 	


SQL> select * from employees;

EMPLOYEE_CODE EMPLOYEE_NAME   DATE_OF_J EMPLOYEE_SALARY GR TITLE
------------- --------------- --------- --------------- -- -----
          101 Preetam         10-JAN-10           18000 A
          102 Aakash          10-NOV-05           48000 C
          103 Kishore         19-DEC-11           21000 B
          104 Reena           23-JUN-06           42000 C
          105 Kailash         05-FEB-04           46000 C
          107 Keerthana       25-JUL-06           27000 B
          106 Sahana          18-NOV-03           52000 C
          148 suma            23-JUN-18           40000 A  Mrs
          149 Sumanth         23-JUN-18           30000 C  Mr

9 rows selected.
   

SQL> DROP TABLE employees;

Table dropped.

SQL> DROP TABLE salgrade;

Table dropped.


SQL> DROP SEQUENCE empCode_Seq;

Sequence dropped.

 SQL> commit;

Commit complete.