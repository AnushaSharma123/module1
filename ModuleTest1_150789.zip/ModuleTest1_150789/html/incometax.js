function getTax()
{
var emp_first_name=document.getElementById("f_name").value;
var emp_last_name=document.getElementById("l_name").value;
var emp_fullname=emp_first_name+emp_last_name;

var emp_gross_salary=document.getElementById("g_sal").value;

var netSalary=0;

if(emp_gross_salary<180000)
{
	netSalary=window.open("", "", "width=500,height=500");
	netSalary.document.write("Name is "+emp_fullname+" "+"Income Tax is Nil and Net Salary is "+emp_gross_salary);
}
else if(emp_gross_salary>180001 && emp_gross_salary<300000)
{
	netSalary=window.open("", "", "width=500,height=500");
	netSalary.document.write("Name is "+emp_fullname+" "+"Income Tax is "+(emp_gross_salary*0.1)+" Net Salary is "+(emp_gross_salary-(emp_gross_salary*0.1)));
}
else if(emp_gross_salary>300001 && emp_gross_salary<500000)
{
	netSalary=window.open("", "", "width=500,height=500");
	netSalary.document.write("Name is "+emp_fullname+" "+"Income Tax is "+(emp_gross_salary*0.2)+" Net Salary is "+(emp_gross_salary-(emp_gross_salary*0.2)));
}
else{
	netSalary=window.open("", "", "width=500,height=500");
	netSalary.document.write("Name is "+emp_fullname+" "+"Income Tax is "+(emp_gross_salary*0.3)+" Net Salary is "+(emp_gross_salary-(emp_gross_salary*0.3)));
}
} 
