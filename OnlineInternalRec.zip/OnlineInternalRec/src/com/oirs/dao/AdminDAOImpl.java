package com.oirs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.ws.Response;

import com.oirs.bean.userBean;
import com.oirs.exception.OIRSException;
import com.oirs.util.DBConnection;

public class AdminDAOImpl implements IAdminDAO{

	userBean userbean =new userBean();

	PreparedStatement preparedstatement=null;		
	ResultSet resultSet = null;
	int queryResult=0;

	@Override
	public String addNewUser(userBean userBean) throws OIRSException {
		Connection connection = DBConnection.getConnection();	
		String result=null;
		int rs;
		try{
			preparedstatement=connection.prepareStatement(IQueryMapper.ADDUSER);
			preparedstatement.setString(1, userBean.getUserId());
			preparedstatement.setString(2, userBean.getUserPassword());
			preparedstatement.setString(3, userBean.getUserRole());
			preparedstatement.setString(4, userBean.getHint());
			rs = preparedstatement.executeUpdate();
			if(rs > 0)
			{
				result = "User Added Successfully!!!";
			}
			else
			{
				throw new OIRSException("Inserting user details failed ");

			}
			return result;
		}catch(SQLException sqlexception)
		{
			throw new OIRSException("SQL error occured "+sqlexception.getMessage());
		}

		finally
		{
			try 
			{

				preparedstatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{

				throw new OIRSException("Error in closing db connection");

			}
		}
	}

	@Override
	public String assignRole(String userId, String role) throws OIRSException {

		Connection connection = DBConnection.getConnection();
		String result=null;
		
		try{
			
			preparedstatement=connection.prepareStatement(IQueryMapper.ASSIGNROLE);
			preparedstatement.setString(1,role);
			preparedstatement.setString(2, userId);
			
			int queryResult = preparedstatement.executeUpdate();
			
			if(queryResult!=0){
				result = "Role updated Successfully for "+userId;
				System.out.println(result);
			}
			else
			{
				System.out.println("Updation failed");
			}
		}catch(Exception e)
		{
			throw new OIRSException("Error "+e.getMessage());
		}
		finally
		{
			try 
			{
				connection.close();
			} 
			catch (SQLException e) 
			{

				throw new OIRSException("Error in closing db connection"+e.getMessage());

			}
		}
		return result;

	}



	@Override
	public String deleteUser(String userId) throws OIRSException {
		Connection connection = DBConnection.getConnection();
		String result=null;
		try{
			result=userbean.getUserId();
			preparedstatement=connection.prepareStatement(IQueryMapper.DELETEUSER);
			preparedstatement.setString(1,userId);
			int r = preparedstatement.executeUpdate();
			if(r > 0){
				result = userId+" deleted!!!";
			}
			else
			{
				System.out.println("Delete failed");
			}
		}catch(Exception e)
		{
			throw new OIRSException("Error in closing db connection");
		}
		finally
		{
			try 
			{
				connection.close();
			} 
			catch (SQLException e) 
			{

				throw new OIRSException("Error in closing db connection"+e.getMessage());

			}
		}
		return result;

	}



	@Override
	public void generateReport() throws OIRSException {
		// TODO Auto-generated method stub

	}
	
	@Override
	public List<String> getUserIds() throws OIRSException {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<>();
		Connection connection = DBConnection.getConnection();
		try {
			preparedstatement=connection.prepareStatement(IQueryMapper.GET_USER_IDS);
			resultSet=preparedstatement.executeQuery();
			while(resultSet.next()){
				list.add(resultSet.getString(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}

}
