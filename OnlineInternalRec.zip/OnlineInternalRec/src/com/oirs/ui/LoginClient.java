package com.oirs.ui;

import java.util.Scanner;

import com.oirs.bean.userBean;
import com.oirs.exception.OIRSException;
import com.oirs.service.AuthenticateServiceImpl;
import com.oirs.service.IAuthenticateService;

public class LoginClient {

	public static void main(String[] args) throws OIRSException {
		// TODO Auto-generated method stub
		IAuthenticateService service = new AuthenticateServiceImpl();
		userBean bean =null;
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the user ID");
		String userId = in.next();
		System.out.println("Enter the password");
		String userPass = in.next();
		try {
			bean = service.loginUser(userId, userPass);
			if(bean != null){
				System.out.println(bean.getUserRole());
			}
			else
			{
				System.out.println("Invalid user");
			}
				
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	}

}
