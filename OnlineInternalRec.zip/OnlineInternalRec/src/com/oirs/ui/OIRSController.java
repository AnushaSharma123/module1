package com.oirs.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.jms.Session;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oirs.bean.EmployeeBean;
import com.oirs.bean.ProjectBean;
import com.oirs.bean.RequisitionBean;
import com.oirs.bean.userBean;
import com.oirs.dao.RMGEDAOImpl;
import com.oirs.exception.OIRSException;
import com.oirs.service.AdminService;
import com.oirs.service.AuthenticateServiceImpl;
import com.oirs.service.IAdminService;
import com.oirs.service.IAuthenticateService;
import com.oirs.service.IRMGEService;
import com.oirs.service.IRMService;
import com.oirs.service.RMGEServiceImpl;
import com.oirs.service.RMServiceImpl;
import com.sun.xml.internal.ws.api.server.InstanceResolverAnnotation;

/**
 * Servlet implementation class OIRSController
 */
@WebServlet("/OIRSController")
public class OIRSController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public OIRSController() {
		super();
		// TODO Auto-generated constructor stub
	}
	userBean userbean = new userBean();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}




	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		IAdminService adminService = new AdminService();
		IRMGEService iRMGEService = new RMGEServiceImpl();
		String option = request.getParameter("action");
		if(option.equals("LogIn")){
			String UserId = request.getParameter("userId");
			String userPassword = request.getParameter("userPassword");
			IAuthenticateService authService = new AuthenticateServiceImpl();
			try {
				userbean = authService.loginUser(UserId, userPassword);
				if(userbean != null){
					String beanRole = userbean.getUserRole().toLowerCase();
					String date =  userbean.getLastLogin();
					System.out.println(date);
					if(beanRole.equals("admin")){
						request.setAttribute("UserBean", userbean);
						session.setAttribute("userId", userbean.getUserId());
						request.setAttribute("logindate", userbean.getLastLogin());
						getServletContext().getRequestDispatcher("/AdminPage.jsp").forward(request,response);
					}
					else if(beanRole.equals("rm")){
						request.setAttribute("UserBean", userbean);
						session.setAttribute("userId", userbean.getUserId());
						getServletContext().getRequestDispatcher("/RmPage.jsp").forward(request,response);
					}
					else if(beanRole.equals("rmge"))
					{
						request.setAttribute("UserBean", userbean);
						session.setAttribute("userId", userbean.getUserId());
						getServletContext().getRequestDispatcher("/RmgePage.jsp").forward(request,response);
					}

					else{
					}
				}
				else
					out.println("Invalid UserName or Password");	
			}catch (OIRSException e) {}


		}
		else if(option.equals("Add New User"))
		{
			getServletContext().getRequestDispatcher("/addUser.jsp").forward(request,response);
		}
		else if(option.equals("Assign Role"))
		{
			try {
				List<String> list = adminService.getUserIds();
				request.setAttribute("userIds", list);
				getServletContext().getRequestDispatcher("/assignRole.jsp").forward(request,response);
			} catch (OIRSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 

		}
		else if(option.equals("Delete User"))
		{
			List<String> list;
			try {
				list = adminService.getUserIds();
				request.setAttribute("userIds", list);
				getServletContext().getRequestDispatcher("/DeleteUser.jsp").forward(request,response);
			} catch (OIRSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		else if(option.equals("Adding New User"))
		{
			String newUserId = request.getParameter("newUserId");
			String newpswd = request.getParameter("newPwd");
			String newRole = request.getParameter("userRole").toLowerCase();
			String newHint = request.getParameter("userHint").toLowerCase();
			userbean.setUserId(newUserId);
			userbean.setUserPassword(newpswd);
			userbean.setUserRole(newRole);
			userbean.setHint(newHint);
			try {
				if(adminService.addNewUser(userbean).equals(null)){
					out.println("Details Not Inserted");
				}
				else{
					out.println("Data inserted succesfully");
				}
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}
		else if(option.equals("Assigning"))
		{
			String assignUserId = request.getParameter("assignId");
			String assignRole = request.getParameter("assignRole");
			userbean.setUserId(assignUserId);
			userbean.setUserRole(assignRole);
			try {
				String res = adminService.assignRole(assignUserId, assignRole);
				if(res==null){
					out.println("User not found!!! Enter the valid user ID");
				}
				else
				{
					out.println("succesfully assigned role");
				}
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}
		else if(option.equals("Delete"))
		{
			String deleteUserId = request.getParameter("deleteUserId");
			userbean.setUserId(deleteUserId);
			try {
				String res = adminService.deleteUser(deleteUserId);
				if(res==null){
					out.print("User not found!!! Enter the valid user ID");
				}
				else{
					out.print("Deleted successfully");
				}
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}
		else if(option.equals("RaiseRequisitions"))
		{
			RequisitionBean reqBean = new RequisitionBean();
			String rmId = userbean.getUserId();
			IRMService rmService = new RMServiceImpl();
			reqBean.setReqRmId(rmId);
			try {
				List<ProjectBean> prjBeanList = rmService.getProjectDetailsByStatus(rmId, "OPEN");
				for(ProjectBean prj : prjBeanList)
				{
					System.out.println(prj.getProjectId()+"\t"+prj.getProjectName());
				}
				request.setAttribute("projectDetails", prjBeanList);
				getServletContext().getRequestDispatcher("/RaiseRequisition.jsp").forward(request,response);
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}
		else if(option.equals("Raise Requisition")){
			RequisitionBean reqBean = new RequisitionBean();
			IRMService rmService = new RMServiceImpl();
			ProjectBean projBean = new ProjectBean();
			String rmId = userbean.getUserId();
			String projId = request.getParameter("projId");
			String skill = request.getParameter("skill").toLowerCase();
			String domain = request.getParameter("domain").toLowerCase();
			int numReq = Integer.parseInt(request.getParameter("number"));
			String vacancy = request.getParameter("vacancy");
			reqBean.setReqRmId(rmId);
			reqBean.setReqProjectId(projId);
			reqBean.setReqSkill(skill);
			reqBean.setReqDomain(domain);
			reqBean.setReqVacancyName(vacancy);
			reqBean.setReqNoReq(numReq);

			try {
				String reqId = rmService.raiseRequisition(reqBean);
				if(reqId.equals(null))
				{
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Error in Raising Requisition');");
					out.println("</script>");

				}
				else{
					String msg = "Requisition Raised Succesfully for Requisition Id "+reqId;
					out.println("<script type=\"text/javascript\">");
					out.println("alert("+msg+");");
					out.println("</script>");
					out.println("Requisition Raised Succesfully for Requisition Id "+reqId);

				}
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}
		else if(option.equals("Accept/Reject")){




		}

		else if(option.equals("Close/unassign")){
			RequisitionBean reqBean = new RequisitionBean();
			String rmId = userbean.getUserId();
			IRMService rmService = new RMServiceImpl();
			reqBean.setReqRmId(rmId);
			try {
				List<ProjectBean> prjBeanList = rmService.getProjectDetailsByStatus(rmId, "OPEN");
				for(ProjectBean prj : prjBeanList)
				{
					System.out.println(prj.getProjectId()+"\t"+prj.getProjectName());
				}
				request.setAttribute("projectDetails", prjBeanList);
				getServletContext().getRequestDispatcher("/closeUnasignProj.jsp").forward(request,response);
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}

		else if(option.equals("Close Project"))
		{
			String projId = request.getParameter("projId");
			IRMService rmService = new RMServiceImpl();
			try {
				boolean result = rmService.unassignByPrjId(projId);
				if(result == true){
					out.println("Project Closed Succesfully");
				}
				else{
					out.println("Failed Closing the project");
				}
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}
		else if(option.equals("Unassign Employee"))
		{
			IRMService rmService = new RMServiceImpl();
			String prjId = request.getParameter("projId");
			try {
				List<EmployeeBean> bean = rmService.getEmpDetailsByPrjId(prjId);
				request.setAttribute("empBean", bean);
				request.setAttribute("prjId", prjId);
				getServletContext().getRequestDispatcher("/RMUnassignByEmpID.jsp").forward(request, response);
			} catch (OIRSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		else if(option.equals("unassignEmployee")){
			IRMService rmService = new RMServiceImpl();
			String empId = request.getParameter("empId");
			try {
				boolean result = rmService.unassignProject(empId);
				String prjId =  (String) request.getAttribute("prjId");
				List<EmployeeBean> bean = rmService.getEmpDetailsByPrjId(prjId);
				request.setAttribute("empBean", bean);
				getServletContext().getRequestDispatcher("/RMUnassignByEmpID.jsp").forward(request, response);
			} catch (OIRSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		else if(option.equals("ViewAllRequisitions"))
		{
			List<RequisitionBean> reqBeanList;
			try {
				reqBeanList = iRMGEService.getAllRequisitions();
				for(RequisitionBean req : reqBeanList)
				{
					System.out.println(req.getReqId()+"\t"+req.getReqRmId());
				}
				request.setAttribute("reqDetails", reqBeanList);
				getServletContext().getRequestDispatcher("/allRequisitions.jsp").forward(request,response);
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}
		else if(option.equals("View Requisition details"))
		{
			String reqId = request.getParameter("reqId");
			try {
				RequisitionBean reqBean = iRMGEService.getRequisitionDetails(reqId);
				request.setAttribute("reqBean", reqBean);
				getServletContext().getRequestDispatcher("/ViewRequisitionDetails.jsp").forward(request,response);
			} catch (OIRSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		else if(option.equals("Search Employee"))
		{

			RequisitionBean reqBean = (RequisitionBean) session.getAttribute("reqBean");

			//System.out.println(request.getAttribute("reqBean"));
			System.out.println(reqBean.getReqId()+ "-------Search");
			System.out.println(reqBean.getReqSkill()+ "-------Search");
			System.out.println(session.getAttribute("reqId")+"-----Session reqId");

			try {
				List<EmployeeBean> empList = iRMGEService.searchEmployee(reqBean);
				//request.setAttribute("reqId", reqBean.getReqId());
				request.setAttribute("numReq", reqBean.getReqNoReq());
				request.setAttribute("empList", empList);
				getServletContext().getRequestDispatcher("/searchEmployee.jsp").forward(request,response);

			} catch (OIRSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		else if(option.equals("View Employee Details")){
			String empId = request.getParameter("empId");
			String reqId = (String) session.getAttribute("reqId");

			System.out.println("Req id -->"+reqId);
			EmployeeBean empBean;
			try {
				empBean = iRMGEService.getEmployeeDetails(empId);
				request.setAttribute("empBean", empBean);
				//request.setAttribute("reqId", reqId);
				getServletContext().getRequestDispatcher("/DisplayEmployeeDetails.jsp").forward(request,response);
			} catch (OIRSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		else if(option.equals("Assign Employee")){
			String reqId = (String) session.getAttribute("reqId");
			String empId = (String) session.getAttribute("empId");
			System.out.println("Assign req -->"+reqId);
			System.out.println("Assign emp -->"+empId);
			try {
				boolean result = iRMGEService.assignProject(empId, reqId);

				System.out.println(result +"Assigned!!");
				if(result){

					getServletContext().getRequestDispatcher("/searchEmployee.jsp").forward(request,response);
				}
				else
				{
					out.print("Failed to assign");
				}


			} catch (OIRSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


			//searchEmployee(reqBean);
		}

	}

}
